function perda = freespaceloss(distancia, frequencia)
perda = 32.45 + 20.0 * (log10(distancia) + log10(frequencia));
end   